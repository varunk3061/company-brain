import { ChevronLeft, ChevronRight } from "lucide-react";

// Page numbers to show: always first and last, the current page and its neighbours, "…" for gaps.
// 1 … 4 5 6 … 12
function pageItems(page, pageCount) {
  if (pageCount <= 7) return Array.from({ length: pageCount }, (_, i) => i + 1);
  const items = [1];
  const start = Math.max(2, page - 1);
  const end = Math.min(pageCount - 1, page + 1);
  if (start > 2) items.push("start-gap");
  for (let p = start; p <= end; p += 1) items.push(p);
  if (end < pageCount - 1) items.push("end-gap");
  items.push(pageCount);
  return items;
}

const btnCls =
  "inline-flex h-8 min-w-8 items-center justify-center rounded-control px-2 text-sm font-medium transition focus:outline-none focus-visible:ring-2 focus-visible:ring-brand disabled:opacity-50";

// Table footer: "Showing 1–8 of 23 users" + Previous / page numbers / Next.
// Always rendered at the same height so the table does not jump while paging or filtering.
export default function Pagination({ page, pageSize, total, onPageChange, noun = "entries" }) {
  const pageCount = Math.max(1, Math.ceil(total / pageSize));
  const current = Math.min(Math.max(1, page), pageCount);
  const from = total === 0 ? 0 : (current - 1) * pageSize + 1;
  const to = Math.min(total, current * pageSize);

  return (
    <nav
      aria-label="Pagination"
      className="flex h-14 items-center justify-between gap-4 border-t border-line px-6 text-sm text-ink-3"
    >
      <span className="truncate">
        {total === 0 ? `No ${noun}` : `Showing ${from}–${to} of ${total} ${noun}`}
      </span>

      <div className="flex shrink-0 items-center gap-1">
        <button
          type="button"
          onClick={() => onPageChange(current - 1)}
          disabled={current <= 1}
          aria-label="Previous page"
          title="Previous page"
          className={`${btnCls} text-ink-2 hover:bg-surface-3`}
        >
          <ChevronLeft className="h-4 w-4" aria-hidden="true" />
        </button>

        {pageItems(current, pageCount).map((item) =>
          typeof item === "number" ? (
            <button
              key={item}
              type="button"
              onClick={() => onPageChange(item)}
              aria-label={`Page ${item}`}
              aria-current={item === current ? "page" : undefined}
              className={`${btnCls} ${
                item === current ? "bg-brand text-on-brand" : "text-ink-2 hover:bg-surface-3"
              }`}
            >
              {item}
            </button>
          ) : (
            <span key={item} className="px-1 text-ink-3" aria-hidden="true">
              …
            </span>
          ),
        )}

        <button
          type="button"
          onClick={() => onPageChange(current + 1)}
          disabled={current >= pageCount}
          aria-label="Next page"
          title="Next page"
          className={`${btnCls} text-ink-2 hover:bg-surface-3`}
        >
          <ChevronRight className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>
    </nav>
  );
}
